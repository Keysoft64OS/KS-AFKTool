﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.StartButton = New System.Windows.Forms.Button()
        Me.Cursorclock = New System.Windows.Forms.Timer(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Dragctrl = New System.Windows.Forms.Timer(Me.components)
        Me.Gamelayer = New System.Windows.Forms.Timer(Me.components)
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Dimensionbox = New System.Windows.Forms.CheckBox()
        Me.Spacebox = New System.Windows.Forms.CheckBox()
        Me.Mousemovingbox = New System.Windows.Forms.CheckBox()
        Me.Keyclock = New System.Windows.Forms.Timer(Me.components)
        Me.KeystrokeFunction = New System.Windows.Forms.CheckBox()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(34, 112)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(279, 30)
        Me.StartButton.TabIndex = 0
        Me.StartButton.Text = "Start/Stop Anti-AFK Killer"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'Cursorclock
        '
        Me.Cursorclock.Interval = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(34, 148)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(279, 21)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "EXIT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Blue
        Me.Panel1.Controls.Add(Me.KeystrokeFunction)
        Me.Panel1.Controls.Add(Me.Mousemovingbox)
        Me.Panel1.Controls.Add(Me.Spacebox)
        Me.Panel1.Controls.Add(Me.Dimensionbox)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.StartButton)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 18)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(345, 181)
        Me.Panel1.TabIndex = 2
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(-1, -1)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(43, 24)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "+"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Dragctrl
        '
        Me.Dragctrl.Interval = 1
        '
        'Gamelayer
        '
        Me.Gamelayer.Enabled = True
        Me.Gamelayer.Interval = 1
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(294, -1)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(52, 24)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "INFO"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Dimensionbox
        '
        Me.Dimensionbox.AutoSize = True
        Me.Dimensionbox.ForeColor = System.Drawing.Color.White
        Me.Dimensionbox.Location = New System.Drawing.Point(3, 89)
        Me.Dimensionbox.Name = "Dimensionbox"
        Me.Dimensionbox.Size = New System.Drawing.Size(342, 17)
        Me.Dimensionbox.TabIndex = 2
        Me.Dimensionbox.Text = "Keep pressing WASD In circular formation [ 3D Games ]"
        Me.Dimensionbox.UseVisualStyleBackColor = True
        '
        'Spacebox
        '
        Me.Spacebox.AutoSize = True
        Me.Spacebox.ForeColor = System.Drawing.Color.White
        Me.Spacebox.Location = New System.Drawing.Point(3, 66)
        Me.Spacebox.Name = "Spacebox"
        Me.Spacebox.Size = New System.Drawing.Size(244, 17)
        Me.Spacebox.TabIndex = 3
        Me.Spacebox.Text = "Keep pressing space [ 2D/3D Games ]"
        Me.Spacebox.UseVisualStyleBackColor = True
        '
        'Mousemovingbox
        '
        Me.Mousemovingbox.AutoSize = True
        Me.Mousemovingbox.ForeColor = System.Drawing.Color.White
        Me.Mousemovingbox.Location = New System.Drawing.Point(3, 20)
        Me.Mousemovingbox.Name = "Mousemovingbox"
        Me.Mousemovingbox.Size = New System.Drawing.Size(97, 17)
        Me.Mousemovingbox.TabIndex = 6
        Me.Mousemovingbox.Text = "Move mouse"
        Me.Mousemovingbox.UseVisualStyleBackColor = True
        '
        'Keyclock
        '
        Me.Keyclock.Interval = 2000
        '
        'KeystrokeFunction
        '
        Me.KeystrokeFunction.AutoSize = True
        Me.KeystrokeFunction.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.KeystrokeFunction.Location = New System.Drawing.Point(3, 43)
        Me.KeystrokeFunction.Name = "KeystrokeFunction"
        Me.KeystrokeFunction.Size = New System.Drawing.Size(122, 17)
        Me.KeystrokeFunction.TabIndex = 7
        Me.KeystrokeFunction.Text = "Allow Keystrokes"
        Me.KeystrokeFunction.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(345, 199)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "ANTI-AFK"
        Me.TopMost = True
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents StartButton As Button
    Friend WithEvents Cursorclock As Timer
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Dragctrl As Timer
    Friend WithEvents Gamelayer As Timer
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Mousemovingbox As CheckBox
    Friend WithEvents Spacebox As CheckBox
    Friend WithEvents Dimensionbox As CheckBox
    Friend WithEvents Keyclock As Timer
    Friend WithEvents KeystrokeFunction As CheckBox
End Class
