﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Gamelayer.Start()
    End Sub
    Dim onoff As Boolean = False

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles StartButton.Click
        If onoff = False Then
            If Mousemovingbox.Checked = True Then
                Cursorclock.Start()

            End If
            If KeystrokeFunction.Checked = True Then
                Keyclock.Start()
            End If
            onoff = True
        Else
            Keyclock.Stop()
            Cursorclock.Stop()
            onoff = False
        End If


    End Sub

    Private Sub Cursorclock_Tick(sender As Object, e As EventArgs) Handles Cursorclock.Tick
        Windows.Forms.Cursor.Position = New Point(Windows.Forms.Cursor.Position.X + 5, Windows.Forms.Cursor.Position.Y)
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Dragdrop_Tick(sender As Object, e As EventArgs) Handles Dragctrl.Tick
        Me.Location = Windows.Forms.Cursor.Position
    End Sub
    Dim drgctrl As Boolean = False
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If drgctrl = False Then
            Dragctrl.Start()
            drgctrl = True
        Else
            Dragctrl.Stop()
            drgctrl = False
        End If

    End Sub

    Private Sub Gamelayer_Tick(sender As Object, e As EventArgs) Handles Gamelayer.Tick
        Me.BringToFront()

    End Sub
    Dim WSTrigger As Boolean = False
    Private Sub Keyclock_Tick(sender As Object, e As EventArgs) Handles Keyclock.Tick
        If Dimensionbox.Checked = True Then


            If WSTrigger = False Then
                SendKeys.Send("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd")
                WSTrigger = True
            Else
                SendKeys.Send("ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
                WSTrigger = False
            End If
        End If
        If Spacebox.Checked = True Then
            SendKeys.Send("                                         ")
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        info.Show()
    End Sub
End Class
